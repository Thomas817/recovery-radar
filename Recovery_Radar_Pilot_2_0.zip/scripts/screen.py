#!/usr/bin/env python3
"""Rotierender, kursbasierter Recovery-Radar-Pilot ohne externe Python-Pakete."""
from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
UNIVERSE_PATH = ROOT / "scripts" / "universe.json"
RESULTS_PATH = ROOT / "data" / "results.json"
HISTORY_PATH = ROOT / "data" / "history.json"
API_BASE = "https://eodhd.com/api/eod"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def fetch_eod(symbol: str, api_key: str, days: int = 370) -> list[dict[str, Any]]:
    start = (utc_now() - timedelta(days=days)).date().isoformat()
    params = urllib.parse.urlencode({
        "api_token": api_key,
        "fmt": "json",
        "from": start,
        "period": "d",
        "order": "a",
    })
    url = f"{API_BASE}/{urllib.parse.quote(symbol)}?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": "RecoveryRadarPilot/2.0"})
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body[:180]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Netzwerkfehler: {exc.reason}") from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Ungültige API-Antwort: {raw[:180]}") from exc

    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or data.get("code")
        raise RuntimeError(str(message or data)[:220])
    if not isinstance(data, list) or len(data) < 20:
        raise RuntimeError("Zu wenige historische Kursdaten")
    return data


def closes_from_rows(rows: list[dict[str, Any]]) -> list[tuple[str, float]]:
    values: list[tuple[str, float]] = []
    for row in rows:
        raw = row.get("adjusted_close", row.get("close"))
        try:
            price = float(raw)
        except (TypeError, ValueError):
            continue
        if price > 0 and row.get("date"):
            values.append((str(row["date"]), price))
    return values


def pct(current: float, prior: float) -> float | None:
    if prior <= 0:
        return None
    return (current / prior - 1.0) * 100.0


def nearest_return(series: list[tuple[str, float]], sessions: int) -> float | None:
    if len(series) <= sessions:
        return None
    return pct(series[-1][1], series[-1 - sessions][1])


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def calculate_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    series = closes_from_rows(rows)
    if len(series) < 20:
        raise RuntimeError("Nicht genügend verwertbare Schlusskurse")

    prices = [v for _, v in series]
    current = prices[-1]
    year = prices[-252:] if len(prices) >= 252 else prices
    low = min(year)
    high = max(year)

    daily_returns = []
    for a, b in zip(year, year[1:]):
        if a > 0:
            daily_returns.append((b / a) - 1.0)
    volatility = statistics.pstdev(daily_returns) * math.sqrt(252) * 100 if len(daily_returns) > 5 else 0.0

    ret_1m = nearest_return(series, 21)
    ret_3m = nearest_return(series, 63)
    ret_6m = nearest_return(series, 126)
    ret_12m = nearest_return(series, min(252, len(series) - 1))
    from_low = pct(current, low) or 0.0
    below_high = (current / high - 1.0) * 100.0 if high > 0 else 0.0

    # Kursbasierter Pilot-Score: starke historische Schwäche + erkennbare Stabilisierung.
    underperformance = clamp((-(ret_12m or 0.0) + -(ret_6m or 0.0) * 0.6) / 2.0, 0, 45)
    recovery = clamp((ret_1m or 0.0) * 0.8 + (ret_3m or 0.0) * 0.55 + from_low * 0.22, 0, 35)
    setup = clamp((-below_high - 8) * 0.35, 0, 15)
    risk_penalty = clamp((volatility - 28) * 0.35, 0, 18)
    score = round(clamp(25 + underperformance + recovery + setup - risk_penalty, 0, 100), 1)

    reasons = []
    if (ret_12m or 0) <= -20:
        reasons.append("deutliche Schwäche über zwölf Monate")
    elif (ret_12m or 0) < 0:
        reasons.append("negative Zwölfmonatsentwicklung")
    if below_high <= -30:
        reasons.append("großer Abstand zum 52-Wochen-Hoch")
    if (ret_3m or 0) > 8:
        reasons.append("positive Erholung über drei Monate")
    if from_low > 15:
        reasons.append("spürbare Stabilisierung vom Jahrestief")
    if volatility > 45:
        reasons.append("erhöhte Volatilität begrenzt den Score")
    if not reasons:
        reasons.append("gemischtes technisches Erholungsbild")

    chart = [{"date": d, "close": round(v, 4)} for d, v in series[-260:]]
    return {
        "price": round(current, 4),
        "currency": None,
        "priceDate": series[-1][0],
        "performance": {
            "1m": round(ret_1m, 2) if ret_1m is not None else None,
            "3m": round(ret_3m, 2) if ret_3m is not None else None,
            "6m": round(ret_6m, 2) if ret_6m is not None else None,
            "12m": round(ret_12m, 2) if ret_12m is not None else None,
        },
        "yearLow": round(low, 4),
        "yearHigh": round(high, 4),
        "fromYearLow": round(from_low, 2),
        "belowYearHigh": round(below_high, 2),
        "volatility": round(volatility, 2),
        "score": score,
        "scoreComponents": {
            "underperformance": round(underperformance, 1),
            "recovery": round(recovery, 1),
            "setup": round(setup, 1),
            "riskPenalty": round(risk_penalty, 1),
        },
        "scoreExplanation": reasons,
        "chart": chart,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch-size", type=int, default=15)
    parser.add_argument("--sleep", type=float, default=1.2)
    args = parser.parse_args()

    api_key = os.environ.get("EODHD_API_KEY", "").strip()
    if not api_key:
        print("Fehler: EODHD_API_KEY ist nicht gesetzt.", file=sys.stderr)
        return 2

    universe = load_json(UNIVERSE_PATH, [])
    old = load_json(RESULTS_PATH, {})
    old_items = {item.get("symbol"): item for item in old.get("items", []) if item.get("symbol")}
    meta = old.get("meta", {})
    cursor = int(meta.get("cursor", 0)) % max(len(universe), 1)
    batch_size = max(1, min(args.batch_size, len(universe)))
    selected = [universe[(cursor + i) % len(universe)] for i in range(batch_size)]

    now = utc_now()
    errors = []
    updated_symbols = []
    for idx, stock in enumerate(selected, start=1):
        symbol = stock["symbol"]
        print(f"[{idx}/{batch_size}] {symbol}")
        base = dict(old_items.get(symbol, {}))
        base.update(stock)
        try:
            metrics = calculate_metrics(fetch_eod(symbol, api_key))
            prior_score = base.get("score")
            base.update(metrics)
            base["previousScore"] = prior_score
            base["scoreChange"] = round(metrics["score"] - prior_score, 1) if isinstance(prior_score, (int, float)) else None
            base["lastChecked"] = now.isoformat()
            base["status"] = "ok"
            base.pop("error", None)
            updated_symbols.append(symbol)
        except Exception as exc:  # noqa: BLE001 - Fehler wird bewusst pro Aktie isoliert.
            base["lastChecked"] = now.isoformat()
            base["status"] = "error"
            base["error"] = str(exc)
            errors.append({"symbol": symbol, "message": str(exc)})
            print(f"  Fehler: {exc}", file=sys.stderr)
        old_items[symbol] = base
        if idx < batch_size:
            time.sleep(max(0, args.sleep))

    # Noch nie aktualisierte Titel bleiben sichtbar, aber ohne erfundene Marktdaten.
    for stock in universe:
        old_items.setdefault(stock["symbol"], {**stock, "status": "pending", "score": None, "lastChecked": None})

    items = list(old_items.values())
    scored = sorted(
        [x for x in items if isinstance(x.get("score"), (int, float))],
        key=lambda x: (-float(x["score"]), x.get("name", "")),
    )
    unscored = sorted([x for x in items if not isinstance(x.get("score"), (int, float))], key=lambda x: x.get("name", ""))
    items = scored + unscored
    for rank, item in enumerate(scored, start=1):
        previous_rank = item.get("rank")
        item["previousRank"] = previous_rank
        item["rank"] = rank
        item["rankChange"] = (previous_rank - rank) if isinstance(previous_rank, int) else None

    next_cursor = (cursor + batch_size) % len(universe)
    results = {
        "meta": {
            "version": 2,
            "generatedAt": now.isoformat(),
            "universeSize": len(universe),
            "scoredCount": len(scored),
            "batchSize": batch_size,
            "cursor": next_cursor,
            "updatedSymbols": updated_symbols,
            "errors": errors,
            "method": "Kursbasierter Pilot-Score; keine Anlageberatung",
        },
        "items": items,
    }
    save_json(RESULTS_PATH, results)

    history = load_json(HISTORY_PATH, {"runs": []})
    runs = history.get("runs", [])
    runs.append({
        "generatedAt": now.isoformat(),
        "updatedSymbols": updated_symbols,
        "errorCount": len(errors),
        "top": [{"symbol": x["symbol"], "score": x["score"]} for x in scored[:20]],
    })
    history["runs"] = runs[-120:]
    save_json(HISTORY_PATH, history)
    print(f"Fertig: {len(updated_symbols)} aktualisiert, {len(errors)} Fehler, nächster Cursor {next_cursor}.")
    return 0 if updated_symbols else 1


if __name__ == "__main__":
    raise SystemExit(main())
